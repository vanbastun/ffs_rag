from __future__ import annotations
import json
from pathlib import Path
from typing import Any

def load_eval(path: str) -> list[dict[str, Any]]:
    ds = []
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    with p.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                ds.append(json.loads(line))
    return ds

def iter_questions(ds: list[dict[str, Any]]):
    for rec in ds:
        yield rec["id"], rec["question"]

def get_gold_context(rec: dict[str, Any]) -> list[str]:
    return rec.get("gold_chunk_ids", [])