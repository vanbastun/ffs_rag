from __future__ import annotations
from typing import List, Dict, Set

def recall_at_k(retrieved_ids: List[str], gold_ids: Set[str], k: int) -> float:
    if not gold_ids: return 0.0
    top = set(retrieved_ids[:k])
    return len(top & gold_ids) / len(gold_ids)