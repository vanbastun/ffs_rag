from __future__ import annotations
from typing import Iterable, List, Dict

def _simple_tokens(text: str) -> List[str]:
    return text.split()

def split_into_chunks(text: str, chunk_tokens: int = 350, overlap: int = 50) -> List[Dict]:
    tokens = _simple_tokens(text)
    chunks = []
    start = 0
    while start < len(tokens):
        end = min(start + chunk_tokens, len(tokens))
        chunk = " ".join(tokens[start:end])
        chunks.append({"text": chunk})
        if end == len(tokens): break
        start = end - overlap
        if start < 0: start = 0
    return chunks

def normalize_text(text: str) -> str:
    return " ".join(text.strip().split())