from __future__ import annotations
import json
from pathlib import Path
from typing import List, Dict, Tuple
import numpy as np

try:
    import faiss
except ImportError:
    faiss = None

class FaissIndex:
    """FAISS IVF/Flat (по умолчанию Flat L2) с простым id-map."""
    def __init__(self, dim: int, path: str, idmap_path: str):
        if faiss is None:
            raise ImportError("Install faiss-cpu")
        self.dim = dim
        self.path = Path(path)
        self.idmap_path = Path(idmap_path)
        self.index = faiss.IndexFlatIP(dim)  # косинус при нормализованных векторах

    def build(self, vectors: np.ndarray):
        assert vectors.shape[1] == self.dim, "Dimension mismatch"
        self.index.add(vectors)

    def save(self, ids: List[str], metadatas: List[Dict]):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self.index, str(self.path))
        with self.idmap_path.open("w", encoding="utf-8") as f:
            for i, (id_, meta) in enumerate(zip(ids, metadatas)):
                f.write(json.dumps({"pos": i, "id": id_, "meta": meta}, ensure_ascii=False) + "\n")

    def load(self):
        self.index = faiss.read_index(str(self.path))

    def search(self, vectors: np.ndarray, top_k: int) -> Tuple[np.ndarray, np.ndarray]:
        return self.index.search(vectors, top_k)

def load_idmap(idmap_path: str) -> List[Dict]:
    rows = []
    with Path(idmap_path).open(encoding="utf-8") as f:
        for line in f:
            if line.strip(): rows.append(json.loads(line))
    return rows