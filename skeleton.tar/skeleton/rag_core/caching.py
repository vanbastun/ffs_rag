from __future__ import annotations
import json, time, hashlib
from pathlib import Path
from typing import Any, Callable, Optional

class FileCache:
    """Файловый кэш с TTL. Сохраняет JSON по ключу-hash."""
    def __init__(self, cache_dir: str = ".rag_cache", ttl_seconds: Optional[int] = None):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.ttl = ttl_seconds

    def _path(self, key: str) -> Path:
        h = hashlib.sha1(key.encode("utf-8")).hexdigest()
        return self.cache_dir / f"{h}.json"

    def get(self, key: str) -> Optional[Any]:
        p = self._path(key)
        if not p.exists():
            return None
        with p.open(encoding="utf-8") as f:
            obj = json.load(f)
        if self.ttl is not None and time.time() - obj.get("_ts", 0) > self.ttl:
            try: p.unlink()
            except FileNotFoundError: pass
            return None
        return obj.get("value")

    def set(self, key: str, value: Any) -> None:
        p = self._path(key)
        with p.open("w", encoding="utf-8") as f:
            json.dump({"_ts": time.time(), "value": value}, f, ensure_ascii=False)

    def clear(self) -> None:
        for f in self.cache_dir.glob("*.json"):
            f.unlink()

def cache_result(cache: FileCache, key_fn: Callable[..., str]) -> Callable:
    """Декоратор для кэширования результата функции."""
    def deco(fn: Callable) -> Callable:
        def wrapper(*args, **kwargs):
            key = key_fn(*args, **kwargs)
            if (val := cache.get(key)) is not None:
                return val
            res = fn(*args, **kwargs)
            cache.set(key, res)
            return res
        return wrapper
    return deco