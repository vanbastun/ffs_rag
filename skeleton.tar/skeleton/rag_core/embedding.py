from __future__ import annotations
from dataclasses import dataclass
from typing import List
import numpy as np

try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    SentenceTransformer = None

@dataclass
class EmbedConfig:
    model_name: str
    normalize: bool = True
    batch_size: int = 64

class Embedder:
    """Обёртка над sentence-transformers (по умолчанию локальная модель)."""
    def __init__(self, cfg: EmbedConfig):
        if SentenceTransformer is None:
            raise ImportError("Install sentence-transformers")
        self.model = SentenceTransformer(cfg.model_name)
        self.cfg = cfg

    def embed_texts(self, texts: List[str]) -> np.ndarray:
        vecs = self.model.encode(texts, batch_size=self.cfg.batch_size, convert_to_numpy=True, normalize_embeddings=self.cfg.normalize)
        return vecs.astype(np.float32)