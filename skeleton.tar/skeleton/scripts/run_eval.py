from __future__ import annotations
import yaml
from rag_core.embedding import Embedder, EmbedConfig
from rag_core.indexing import FaissIndex, load_idmap
from rag_core.retrieval import Retriever
from src.eval.datasets import load_eval
from src.eval.metrics import recall_at_k

def main():
    cfg = yaml.safe_load(open("configs/config.yaml", encoding="utf-8"))
    emb = Embedder(EmbedConfig(**cfg["embedding"]))
    index = FaissIndex(cfg["index"]["dim"], cfg["index"]["path"], cfg["index"]["idmap_path"])
    index.load()
    idmap = load_idmap(cfg["index"]["idmap_path"])
    retriever = Retriever(index, idmap, emb)

    ds = load_eval(cfg["eval"]["dataset_path"])
    k = cfg["retrieval"]["top_k"]
    scores = []
    for rec in ds:
        res = retriever.retrieve(rec["question"], top_k=k)
        ret_ids = [r["id"] for r in res]
        score = recall_at_k(ret_ids, set(rec.get("gold_chunk_ids", [])), k)
        scores.append(score)
    print(f"Recall@{k}: {sum(scores)/len(scores):.3f}")

if __name__ == "__main__":
    main()