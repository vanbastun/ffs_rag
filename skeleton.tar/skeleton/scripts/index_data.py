from __future__ import annotations
import json, uuid, yaml
from pathlib import Path
from typing import List, Dict
from rag_core.preprocessing import normalize_text, split_into_chunks
from rag_core.embedding import Embedder, EmbedConfig
from rag_core.indexing import FaissIndex

def load_raw_docs(dir_path: str = "data/raw") -> List[Dict]:
    docs = []
    for p in Path(dir_path).glob("**/*"):
        if p.suffix.lower() in {".txt", ".md"}:
            docs.append({"id": p.stem, "text": p.read_text(encoding="utf-8"), "source": str(p)})
    return docs

def main():
    cfg = yaml.safe_load(open("configs/config.yaml", encoding="utf-8"))

    raw_docs = load_raw_docs()
    chunks, ids, metas = [], [], []
    for doc in raw_docs:
        text = normalize_text(doc["text"])
        for i, ch in enumerate(split_into_chunks(text, cfg["preprocessing"]["chunk_tokens"], cfg["preprocessing"]["chunk_overlap"])):
            cid = f"{doc['id']}#{i}"
            ids.append(cid)
            meta = {"doc_id": doc["id"], "chunk": i, "text": ch["text"], "source": doc["source"]}
            metas.append(meta)
            chunks.append(ch["text"])

    emb = Embedder(EmbedConfig(**cfg["embedding"]))
    vecs = emb.embed_texts(chunks)

    index = FaissIndex(cfg["index"]["dim"], cfg["index"]["path"], cfg["index"]["idmap_path"])
    index.build(vecs)
    index.save(ids, metas)
    print(f"Indexed chunks: {len(ids)}")

if __name__ == "__main__":
    main()