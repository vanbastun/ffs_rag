from __future__ import annotations
import numpy as np
import yaml
from rag_core.embedding import Embedder, EmbedConfig
from rag_core.indexing import FaissIndex
from rag_core.retrieval import Retriever

def test_retrieval_smoke(tmp_path, monkeypatch):
    cfg = {"model_name": "sentence-transformers/all-MiniLM-L6-v2", "normalize": True, "batch_size": 8}
    emb = Embedder(EmbedConfig(**cfg))
    vecs = emb.embed_texts(["hello world", "password policy", "network security"])
    index = FaissIndex(dim=vecs.shape[1], path=str(tmp_path/"faiss.index"), idmap_path=str(tmp_path/"idmap.jsonl"))
    index.build(vecs)
    index.save(["a#0","b#0","c#0"], [{"text":"hello world"},{"text":"password policy"},{"text":"network security"}])
    index.load()
    from rag_core.indexing import load_idmap
    idmap = load_idmap(str(tmp_path/"idmap.jsonl"))
    retriever = Retriever(index, idmap, emb)
    res = retriever.retrieve("policy", top_k=2)
    assert len(res) >= 1