from __future__ import annotations
import os, yaml
from pathlib import Path
from typing import List, Dict
from fastapi import FastAPI
from pydantic import BaseModel

from rag_core.embedding import Embedder, EmbedConfig
from rag_core.indexing import FaissIndex, load_idmap
from rag_core.retrieval import Retriever
from rag_core.generation import TemplateGenerator

class QueryRequest(BaseModel):
    question: str
    top_k: int | None = None

def load_cfg(path: str = "configs/config.yaml") -> dict:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)

def build_app() -> FastAPI:
    cfg = load_cfg()
    app = FastAPI(title="RAG Skeleton API")

    emb = Embedder(EmbedConfig(**cfg["embedding"]))
    index = FaissIndex(dim=cfg["index"]["dim"], path=cfg["index"]["path"], idmap_path=cfg["index"]["idmap_path"])
    index.load()
    idmap = load_idmap(cfg["index"]["idmap_path"])
    retriever = Retriever(index, idmap, emb)
    generator = TemplateGenerator()

    @app.get("/health")
    def health():
        return {"status": "ok"}

    @app.post("/query")
    def query(req: QueryRequest):
        top_k = req.top_k or cfg["retrieval"]["top_k"]
        ctxs = retriever.retrieve(req.question, top_k=top_k)
        gen = generator.generate(req.question, ctxs)
        return {"answer": gen["answer"], "contexts": ctxs}

    return app

app = build_app()